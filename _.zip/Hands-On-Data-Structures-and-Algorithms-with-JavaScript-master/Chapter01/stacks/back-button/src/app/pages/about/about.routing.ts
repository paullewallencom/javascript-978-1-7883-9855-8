import { AboutComponent } from './about.component';

export const AboutRoutes = [
    { path: 'about', component: AboutComponent },
];

export const AboutComponents = [
    AboutComponent
];