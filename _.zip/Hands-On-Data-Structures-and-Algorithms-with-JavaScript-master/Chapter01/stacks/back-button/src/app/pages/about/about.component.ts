import { Component } from '@angular/core';

@Component({
    selector: 'about',
    template: 'about page'
})
export class AboutComponent {

}
