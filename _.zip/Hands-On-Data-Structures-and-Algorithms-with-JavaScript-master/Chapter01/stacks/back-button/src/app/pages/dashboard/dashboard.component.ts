import { Component } from '@angular/core';

@Component({
    selector: 'dashboard',
    template: 'dashboard page'
})
export class DashboardComponent {

}
