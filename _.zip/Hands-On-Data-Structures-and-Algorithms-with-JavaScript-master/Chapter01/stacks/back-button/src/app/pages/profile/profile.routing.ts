import { ProfileComponent } from './profile.component';

export const ProfileRoutes = [
    { path: 'profile', component: ProfileComponent },
];

export const ProfileComponents = [
    ProfileComponent
];