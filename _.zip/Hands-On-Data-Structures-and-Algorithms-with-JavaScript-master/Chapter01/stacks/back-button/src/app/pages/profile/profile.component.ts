import { Component } from '@angular/core';

@Component({
    selector: 'profile',
    template: 'profile page'
})
export class ProfileComponent {

}
